#ifndef _MYCLASS
#define _MYCLASS


class MyClass  {


public:

  MyClass();


public: 
  void handleButton();

private:

  std::string initializeWorkingDirectory() const;

  std::string _working_directory;

};

#endif // _MYCLASS
